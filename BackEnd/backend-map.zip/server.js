const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const app = express();
const port = process.env.PORT || 3000;

// Kết nối đến MongoDB
mongoose.connect('mongodb://localhost:27017/potholes', { useNewUrlParser: true, useUnifiedTopology: true });

// Định nghĩa mô hình cho ổ gà
const potholeSchema = new mongoose.Schema({
    lat: Number,
    lang: Number,
    time: { type: Date, default: Date.now },
    severity: { type: Number, min: 1, max: 3 }
});

const Pothole = mongoose.model('Pothole', potholeSchema);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API để thêm ổ gà mới
app.post('/potholes', async (req, res) => {
    const { lat, lang, time, severity } = req.body;
    const pothole = new Pothole({ lat, lang, time, severity });
    await pothole.save();
    res.status(201).send(pothole);
});

// API để lấy danh sách ổ gà
app.get('/potholes', async (req, res) => {
    const potholes = await Pothole.find();
    res.send(potholes);
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});